"""Minimal Airbyte Cloud API client (token + trigger sync + wait). Uses only `requests`."""
from __future__ import annotations

import logging
import os
import time

import requests

log = logging.getLogger(__name__)

HOST = os.environ.get("AIRBYTE_HOST", "https://api.airbyte.com").rstrip("/")
API = f"{HOST}/v1"
TIMEOUT = 30


def _token() -> str:
    r = requests.post(
        f"{API}/applications/token",
        json={
            "client_id": os.environ["AIRBYTE_CLIENT_ID"],
            "client_secret": os.environ["AIRBYTE_CLIENT_SECRET"],
            "grant_type": "client_credentials",
        },
        timeout=TIMEOUT,
    )
    r.raise_for_status()
    return r.json()["access_token"]


def _headers() -> dict:
    return {"Authorization": f"Bearer {_token()}", "Accept": "application/json"}


def get_connection(connection_id: str) -> dict:
    r = requests.get(f"{API}/connections/{connection_id}", headers=_headers(), timeout=TIMEOUT)
    r.raise_for_status()
    return r.json()


def _running_job(connection_id: str) -> str | None:
    r = requests.get(
        f"{API}/jobs",
        params={"connectionId": connection_id, "jobType": "sync", "status": "running", "limit": 1},
        headers=_headers(),
        timeout=TIMEOUT,
    )
    if r.ok:
        data = r.json().get("data") or []
        if data:
            return str(data[0]["jobId"])
    return None


def run_sync(connection_id: str, poll_seconds: int = 15, timeout_seconds: int = 60 * 60) -> dict:
    """Start a sync (or join the one already running) and wait until it finishes."""
    if not connection_id:
        raise ValueError("AIRBYTE_CONNECTION_ID is empty")
    r = requests.post(
        f"{API}/jobs",
        json={"connectionId": connection_id, "jobType": "sync"},
        headers=_headers(),
        timeout=TIMEOUT,
    )
    if r.status_code == 409:  # a sync is already running
        job_id = _running_job(connection_id)
        if not job_id:
            r.raise_for_status()
        log.info("Sync already running, waiting for job %s", job_id)
    else:
        r.raise_for_status()
        job_id = str(r.json()["jobId"])
        log.info("Started Airbyte sync job %s", job_id)

    deadline = time.time() + timeout_seconds
    while time.time() < deadline:
        j = requests.get(f"{API}/jobs/{job_id}", headers=_headers(), timeout=TIMEOUT)
        j.raise_for_status()
        info = j.json()
        status = info.get("status")
        log.info("Job %s status=%s rowsSynced=%s", job_id, status, info.get("rowsSynced"))
        if status == "succeeded":
            return info
        if status in ("failed", "cancelled", "incomplete"):
            raise RuntimeError(f"Airbyte job {job_id} ended with status {status}: {info}")
        time.sleep(poll_seconds)
    raise TimeoutError(f"Airbyte job {job_id} did not finish within {timeout_seconds}s")

-- شغّل ده مرة واحدة في Snowsight بـ ACCOUNTADMIN لو الـ Airflow أو dbt طلعلك "insufficient privileges".
USE ROLE ACCOUNTADMIN;

-- (1) Airflow: يقرأ RAW_DATA وينشئ schema OPS ويكتب فيها
CREATE ROLE IF NOT EXISTS airflow_role;
GRANT USAGE ON WAREHOUSE airbyte_wh TO ROLE airflow_role;
GRANT USAGE ON DATABASE supplychain_dw TO ROLE airflow_role;
GRANT CREATE SCHEMA ON DATABASE supplychain_dw TO ROLE airflow_role;
GRANT USAGE ON SCHEMA supplychain_dw.raw_data TO ROLE airflow_role;
GRANT SELECT ON ALL TABLES IN SCHEMA supplychain_dw.raw_data TO ROLE airflow_role;
GRANT SELECT ON FUTURE TABLES IN SCHEMA supplychain_dw.raw_data TO ROLE airflow_role;
-- لو الـ user اسمه airflow_role فعلاً (زي الـ Documentation) سيبه، وإلا اعمل user:
-- CREATE USER IF NOT EXISTS airflow_user PASSWORD='<password>' DEFAULT_ROLE=airflow_role DEFAULT_WAREHOUSE=airbyte_wh MUST_CHANGE_PASSWORD=FALSE;
-- GRANT ROLE airflow_role TO USER airflow_user;

-- (2) dbt: ينشئ schemas (DBT_STAGING / DBT_MARTS ...) داخل الـ database
GRANT CREATE SCHEMA ON DATABASE supplychain_dw TO ROLE transformer;
-- ولو Airflow بيقرأ نتايج الـ marts للـ quality gate:
-- GRANT ROLE transformer TO ROLE airflow_role;

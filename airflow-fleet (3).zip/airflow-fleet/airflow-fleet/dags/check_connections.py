"""Day-1 smoke test: run this DAG manually to prove Snowflake, S3 and Airbyte are reachable."""
from __future__ import annotations

import logging
import os
from datetime import datetime

from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook

log = logging.getLogger(__name__)
BUCKET = os.environ.get("S3_BRONZE_BUCKET", "supply-chain-graduation-project")


def check_snowflake():
    row = SnowflakeHook(snowflake_conn_id="snowflake_default").get_first(
        "SELECT CURRENT_USER(), CURRENT_ROLE(), CURRENT_WAREHOUSE(), CURRENT_DATABASE()"
    )
    log.info("Snowflake OK -> user=%s role=%s warehouse=%s database=%s", *row)


def check_s3():
    hook = S3Hook(aws_conn_id="aws_default")
    if not hook.check_for_bucket(BUCKET):
        raise ValueError(f"Bucket {BUCKET} not found or no access")
    keys = hook.list_keys(bucket_name=BUCKET, prefix="", max_items=10) or []
    log.info("S3 OK -> bucket=%s, first keys=%s", BUCKET, keys)


def check_airbyte():
    from include.airbyte_client import get_connection

    conn = get_connection(os.environ["AIRBYTE_CONNECTION_ID"])
    log.info("Airbyte OK -> connection=%s status=%s schedule=%s", conn.get("name"), conn.get("status"), conn.get("schedule"))


with DAG(
    dag_id="check_connections",
    start_date=datetime(2026, 10, 1),
    schedule=None,
    catchup=False,
    tags=["setup"],
) as dag:
    PythonOperator(task_id="snowflake", python_callable=check_snowflake)
    PythonOperator(task_id="s3", python_callable=check_s3)
    PythonOperator(task_id="airbyte", python_callable=check_airbyte)
    BashOperator(
        task_id="dbt_debug",
        bash_command="/home/airflow/dbt_venv/bin/dbt debug --connection --project-dir /opt/airflow/dbt --profiles-dir /opt/airflow/dbt",
    )

"""SupplyChain 360 - main pipeline.

Flow (Kafka -> S3 happens outside Airflow, via the Kafka Connect S3 sink in the cloud):

  setup_ops
     -> wait_for_s3 (one sensor per source)
     -> airbyte_sync   (S3 -> Snowflake RAW)
     -> validate_raw   (row counts, optional freshness)
     -> dbt_deps -> dbt_staging -> dbt_snapshot (SCD2) -> dbt_intermediate -> dbt_marts -> dbt_test
     -> quality_gate   (marts not empty)
     -> write_run_report (always runs, writes to OPS.PIPELINE_RUNS)
"""
from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import PythonOperator
from airflow.providers.amazon.aws.sensors.s3 import S3KeySensor
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.providers.snowflake.hooks.snowflake import SnowflakeHook
from airflow.utils.task_group import TaskGroup
from airflow.utils.trigger_rule import TriggerRule

from include.airbyte_client import run_sync

log = logging.getLogger(__name__)

# ---------------------------------------------------------------- config (.env)
DB = os.environ.get("SNOWFLAKE_DATABASE", "SUPPLYCHAIN_DW")
RAW_SCHEMA = os.environ.get("RAW_SCHEMA", "RAW_DATA")
MARTS_SCHEMA = os.environ.get("MARTS_SCHEMA", "DBT_MARTS")
BUCKET = os.environ.get("S3_BRONZE_BUCKET", "supply-chain-graduation-project")
S3_PREFIX = os.environ.get("S3_BRONZE_PREFIX", "fleet/bronze").strip("/")
S3_SOURCES = [s.strip() for s in os.environ.get("S3_SOURCES", "").split(",") if s.strip()]
SKIP_S3_SENSOR = os.environ.get("SKIP_S3_SENSOR", "false").lower() == "true"
AIRBYTE_CONNECTION_ID = os.environ.get("AIRBYTE_CONNECTION_ID", "")
RAW_TABLES = [t.strip() for t in os.environ.get("RAW_TABLES", "").split(",") if t.strip()]
RAW_MAX_AGE_MINUTES = int(os.environ.get("RAW_MAX_AGE_MINUTES", "0"))  # 0 = freshness check off
GATE_TABLES = [t.strip() for t in os.environ.get("GATE_TABLES", "").split(",") if t.strip()]

SNOWFLAKE_CONN_ID = "snowflake_default"
DBT = "/home/airflow/dbt_venv/bin/dbt"
DBT_ARGS = "--project-dir /opt/airflow/dbt --profiles-dir /opt/airflow/dbt"


def _on_failure(context):
    ti = context["task_instance"]
    log.error("TASK FAILED: dag=%s task=%s run=%s", ti.dag_id, ti.task_id, context["run_id"])


def _hook() -> SnowflakeHook:
    return SnowflakeHook(snowflake_conn_id=SNOWFLAKE_CONN_ID)


# ---------------------------------------------------------------- python tasks
def validate_raw(**_):
    """Every RAW table must have rows and (when the Airbyte column exists) fresh data."""
    if not RAW_TABLES:
        raise ValueError("RAW_TABLES is empty - set it in .env")
    hook = _hook()
    counts: dict[str, int] = {}
    problems: list[str] = []
    for table in RAW_TABLES:
        fq = f"{DB}.{RAW_SCHEMA}.{table}"
        n = hook.get_first(f"SELECT COUNT(*) FROM {fq}")[0]
        counts[table] = int(n)
        if n == 0:
            problems.append(f"{fq} is empty")
            continue
        if RAW_MAX_AGE_MINUTES <= 0:
            continue
        try:
            age = hook.get_first(
                f"SELECT DATEDIFF('minute', MAX(_AIRBYTE_EXTRACTED_AT), CURRENT_TIMESTAMP()) FROM {fq}"
            )[0]
            if age is not None and age > RAW_MAX_AGE_MINUTES:
                problems.append(f"{fq} is stale ({age} min old, limit {RAW_MAX_AGE_MINUTES})")
        except Exception as exc:  # column name can differ with Airbyte destination version
            log.warning("Freshness check skipped for %s: %s", fq, exc)
    log.info("RAW row counts: %s", counts)
    if problems:
        raise ValueError("RAW validation failed: " + "; ".join(problems))
    return counts


def quality_gate(**_):
    """Sanity gate on the marts (uniqueness / not-null live in dbt tests)."""
    if not GATE_TABLES:
        log.warning("GATE_TABLES is empty - quality gate skipped (set it once the marts exist)")
        return {}
    hook = _hook()
    counts: dict[str, int] = {}
    empty: list[str] = []
    for table in GATE_TABLES:
        fq = f"{DB}.{MARTS_SCHEMA}.{table}"
        n = int(hook.get_first(f"SELECT COUNT(*) FROM {fq}")[0])
        counts[table] = n
        if n == 0:
            empty.append(fq)
    log.info("MARTS row counts: %s", counts)
    if empty:
        raise ValueError("Quality gate failed, empty tables: " + ", ".join(empty))
    return counts


def write_run_report(**context):
    dag_run = context["dag_run"]
    ti = context["ti"]
    failed = sorted(
        t.task_id
        for t in dag_run.get_task_instances()
        if t.task_id != ti.task_id and t.state in ("failed", "upstream_failed")
    )
    metrics = {
        "raw_counts": ti.xcom_pull(task_ids="validate_raw"),
        "mart_counts": ti.xcom_pull(task_ids="quality_gate"),
    }
    _hook().run(
        f"""INSERT INTO {DB}.OPS.PIPELINE_RUNS
            (RUN_ID, DAG_ID, LOGICAL_DATE, STATUS, FAILED_TASKS, METRICS)
            SELECT %s, %s, %s::TIMESTAMP_TZ, %s, %s, PARSE_JSON(%s)""",
        parameters=[
            dag_run.run_id,
            dag_run.dag_id,
            dag_run.logical_date.isoformat(),
            "failed" if failed else "success",
            ", ".join(failed),
            json.dumps(metrics),
        ],
    )
    log.info("Run report written. status=%s failed=%s", "failed" if failed else "success", failed)


# ---------------------------------------------------------------- DAG
default_args = {
    "owner": "airflow-team",
    "retries": 2,
    "retry_delay": timedelta(minutes=2),
    "retry_exponential_backoff": True,
    "on_failure_callback": _on_failure,
}

with DAG(
    dag_id="supplychain360_pipeline",
    description="S3 -> Airbyte -> Snowflake RAW -> dbt (staging/marts) -> quality gate",
    start_date=datetime(2026, 10, 1),
    schedule="@hourly",
    catchup=False,
    max_active_runs=1,
    default_args=default_args,
    template_searchpath=["/opt/airflow/include/sql"],
    params={"db": DB},
    tags=["supplychain360", "snowflake", "dbt"],
) as dag:

    setup_ops = SQLExecuteQueryOperator(
        task_id="setup_ops",
        conn_id=SNOWFLAKE_CONN_ID,
        sql="00_ops_setup.sql",
        split_statements=True,
    )

    with TaskGroup("wait_for_s3") as wait_for_s3:
        if SKIP_S3_SENSOR:
            EmptyOperator(task_id="skipped")
        else:
            for src in S3_SOURCES:
                S3KeySensor(
                    task_id=f"has_files_{src}",
                    bucket_name=BUCKET,
                    bucket_key=f"{S3_PREFIX}/{src}/*",
                    wildcard_match=True,
                    aws_conn_id="aws_default",
                    poke_interval=30,
                    timeout=10 * 60,
                    mode="reschedule",
                )

    airbyte_sync = PythonOperator(
        task_id="airbyte_sync",
        python_callable=lambda: run_sync(AIRBYTE_CONNECTION_ID),
        retries=0,
        execution_timeout=timedelta(minutes=35),
    )

    validate_raw_task = PythonOperator(task_id="validate_raw", python_callable=validate_raw)

    dbt_deps = BashOperator(task_id="dbt_deps", bash_command=f"{DBT} deps {DBT_ARGS}")
    dbt_staging = BashOperator(task_id="dbt_staging", bash_command=f"{DBT} run --select staging {DBT_ARGS}")
    dbt_snapshot = BashOperator(task_id="dbt_snapshot", bash_command=f"{DBT} snapshot {DBT_ARGS}")
    dbt_intermediate = BashOperator(task_id="dbt_intermediate", bash_command=f"{DBT} run --select intermediate {DBT_ARGS}")
    dbt_marts = BashOperator(task_id="dbt_marts", bash_command=f"{DBT} run --select marts {DBT_ARGS}")
    dbt_test = BashOperator(task_id="dbt_test", bash_command=f"{DBT} test {DBT_ARGS}")

    quality_gate_task = PythonOperator(task_id="quality_gate", python_callable=quality_gate)

    report = PythonOperator(
        task_id="write_run_report",
        python_callable=write_run_report,
        trigger_rule=TriggerRule.ALL_DONE,
    )

    (
        setup_ops
        >> wait_for_s3
        >> airbyte_sync
        >> validate_raw_task
        >> dbt_deps
        >> dbt_staging
        >> dbt_snapshot
        >> dbt_intermediate
        >> dbt_marts
        >> dbt_test
        >> quality_gate_task
        >> report
    )
    # report must also run when something upstream failed
    [setup_ops, airbyte_sync, validate_raw_task, dbt_test, quality_gate_task] >> report

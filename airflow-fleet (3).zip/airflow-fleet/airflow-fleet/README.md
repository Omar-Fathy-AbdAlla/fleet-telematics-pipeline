# Fleet Data Platform — Airflow

Python Generator (EC2) → S3 → Airbyte → Snowflake → dbt → Power BI، وAirflow بينسّق كله.

الـ DAG الرئيسي `supplychain360_pipeline` (كل ساعة):

```
setup_ops → wait_for_s3 → airbyte_sync → validate_raw
         → dbt_deps → dbt_staging → dbt_snapshot → dbt_intermediate → dbt_marts → dbt_test
         → quality_gate → write_run_report
```

القيم اللي في `.env` متاخدة من الـ Documentation (Snowflake `SUPPLYCHAIN_DW`، bucket `supply-chain-graduation-project`، Airbyte connection).

## 1) تنصيب (مرة واحدة)
1. `wsl --install` في PowerShell كـ Admin ثم restart.
2. Docker Desktop (WSL2 engine).
3. `C:\Users\<اسمك>\.wslconfig`:
   ```
   [wsl2]
   memory=4GB
   processors=2
   ```
   ثم `wsl --shutdown`.

## 2) حط مشروع dbt بتاع Mohamed
انسخ محتويات مشروع `supplychain_sic_project` (فولدرات `models/`, `macros/`, `snapshots/`, `tests/`, وملفات `dbt_project.yml` و `packages.yml`) جوه فولدر `dbt/` واستبدل الـ placeholder.
**متنسخش `profiles.yml` بتاعه**؛ اللي هنا بيقرأ من `.env` (اسم الـ profile `supplychain_sic_project`، لازم يطابق `profile:` في `dbt_project.yml`).

## 3) التشغيل
```powershell
cd airflow-fleet
docker compose build            # أول مرة 5-10 دقايق
docker compose up airflow-init  # ينشئ الداتابيز واليوزر والـ connections
docker compose up -d
docker compose ps
```
افتح http://localhost:8080 — `admin` / `admin`.

1. شغّل DAG **check_connections** (Trigger): `snowflake`, `s3`, `airbyte`, `dbt_debug` لازم يبقوا خضر.
2. Unpause **supplychain360_pipeline** وشغّله ▶.

## 4) أوامر مفيدة
```powershell
docker compose logs -f airflow-scheduler
docker compose up -d --force-recreate   # بعد تعديل .env
docker compose up airflow-init          # لو غيّرت بيانات الـ connections
docker compose down                     # إيقاف
```

## 5) لو حصل error
| الـ error | الحل |
|---|---|
| Snowflake: `Incorrect username or password` أو `Role 'AIRFLOW_ROLE' ... not granted` | في الـ Doc `SNOWFLAKE_USER=airflow_role` (اسم role مش user). اسأل Mohamed Farah عن اسم اليوزر الصح وحطه في `SNOWFLAKE_USER`، أو اعمل user بـ `include/sql/snowflake_grants.sql` |
| `Insufficient privileges ... create schema OPS` أو dbt مش قادر ينشئ schema | شغّل `include/sql/snowflake_grants.sql` بـ ACCOUNTADMIN |
| dbt: `warehouse ... does not exist` | الـ Doc كاتب `SNOWFLAKE_DBT_WAREHOUSE=SUPPLYCHAIN_DW` وده اسم الـ database؛ الـ warehouse الصح `AIRBYTE_WH` (متظبط هنا) |
| `airbyte_sync` 401/403 | تأكد من Client ID/Secret وإن الـ trial لسه شغال (الـ Doc فيه "trial ends in 5 days") |
| `wait_for_s3` timeout | الـ generator على EC2 واقف أو الـ prefix غلط. للتجربة `SKIP_S3_SENSOR=true` |
| `validate_raw` جدول فاضي | Airbyte لسه ما عملش sync؛ شغّل Sync now من Airbyte |
| `dbt_test` فشل | في الـ Doc اتعمل `severity: warn` لـ `TRIPS.DRIVER_ID/TRUCK_ID`؛ تأكد إنه موجود في staging.yml اللي نسخته |
| `quality_gate` skipped | طبيعي لحد ما تحط `GATE_TABLES` (بعد ما الـ marts تتبني) |

## 6) ملاحظات
- `validate_raw` من غير فحص freshness (`RAW_MAX_AGE_MINUTES=0`) لأن الجداول static ومش بتتحدث كل ساعة.
- `telemetry` و`reefer` مش متفعّلين في Airbyte حاليًا، فمش في `RAW_TABLES`.
- بعد ما الـ marts تتبني: `GATE_TABLES=DIM_DATE,DIM_DRIVER,DIM_ROUTE,DIM_TRUCK,DIM_TRAILER,...`.
- **ملف `.env` فيه أسرار حقيقية** ومعمول له gitignore. متعملوش commit ولا ترفعه.

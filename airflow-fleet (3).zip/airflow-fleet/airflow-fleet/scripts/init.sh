#!/usr/bin/env bash
# Runs once inside the airflow-init container (safe to re-run).
set -euo pipefail

echo ">> Migrating Airflow metadata DB"
airflow db migrate

echo ">> Creating admin user (${AIRFLOW_ADMIN_USER:-admin})"
airflow users create \
  --username "${AIRFLOW_ADMIN_USER:-admin}" \
  --password "${AIRFLOW_ADMIN_PASSWORD:-admin}" \
  --firstname Admin --lastname User \
  --role Admin --email admin@example.com || true

echo ">> Connection: snowflake_default"
SF_EXTRA=$(python3 - <<'PY'
import json, os
print(json.dumps({
    "account": os.environ["SNOWFLAKE_ACCOUNT"],
    "warehouse": os.environ["SNOWFLAKE_WAREHOUSE"],
    "database": os.environ["SNOWFLAKE_DATABASE"],
    "role": os.environ["SNOWFLAKE_ROLE"],
}))
PY
)
airflow connections delete snowflake_default >/dev/null 2>&1 || true
airflow connections add snowflake_default \
  --conn-type snowflake \
  --conn-login "${SNOWFLAKE_USER}" \
  --conn-password "${SNOWFLAKE_PASSWORD}" \
  --conn-schema "${SNOWFLAKE_SCHEMA:-RAW}" \
  --conn-extra "${SF_EXTRA}"

echo ">> Connection: aws_default"
AWS_EXTRA=$(python3 - <<'PY'
import json, os
print(json.dumps({"region_name": os.environ.get("AWS_DEFAULT_REGION", "us-east-1")}))
PY
)
airflow connections delete aws_default >/dev/null 2>&1 || true
airflow connections add aws_default \
  --conn-type aws \
  --conn-login "${AWS_ACCESS_KEY_ID}" \
  --conn-password "${AWS_SECRET_ACCESS_KEY}" \
  --conn-extra "${AWS_EXTRA}"

echo ">> Connection: airbyte_default"
if [ -n "${AIRBYTE_CLIENT_ID:-}" ] && [ -n "${AIRBYTE_CLIENT_SECRET:-}" ]; then
  airflow connections delete airbyte_default >/dev/null 2>&1 || true
  airflow connections add airbyte_default \
    --conn-type airbyte \
    --conn-host "${AIRBYTE_HOST:-https://api.airbyte.com}" \
    --conn-login "${AIRBYTE_CLIENT_ID}" \
    --conn-password "${AIRBYTE_CLIENT_SECRET}" \
    --conn-extra '{"token_url": "v1/applications/token"}'
else
  echo "   (skipped: AIRBYTE_CLIENT_ID / AIRBYTE_CLIENT_SECRET are empty)"
fi

echo ">> Init finished"
